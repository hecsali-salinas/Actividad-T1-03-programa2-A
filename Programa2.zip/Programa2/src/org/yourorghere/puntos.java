package org.yourorghere;
import com.sun.opengl.util.Animator;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLCapabilities;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.glu.GLU;
import javax.swing.JFrame;

public class puntos extends JFrame {

    static GL gl;
    static GLU glu;

    public puntos() {
        setTitle("cuadricula");

        setSize(1366,730);
        this.setExtendedState(MAXIMIZED_BOTH); 
        
      
        GraphicListener listener = new GraphicListener();
      
        GLCanvas canvas = new GLCanvas(new GLCapabilities());
        canvas.addGLEventListener(listener);
        getContentPane().add(canvas);
        
        setResizable(false);
    }

    public static void main(String args[]) {
        puntos frame = new puntos();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public class GraphicListener implements GLEventListener {

        public void display(GLAutoDrawable arg0) {
            gl.glBegin(GL.GL_POINTS);
            
          
            
            gl.glColor3f(255,0,128);         
            float distancia_entre_lineas = 3f;   
            int num_lineas_hor = 1500/((int)distancia_entre_lineas*10); 
            float au_y=149.8f;   
            float cuanto_x = 0.0f;            
                                           
            for (int hor = 0; hor < num_lineas_hor; hor++) {  
                for (int i = 0; i < 2000; i++) { 
                    gl.glVertex2f(cuanto_x, au_y); 
                    cuanto_x += 0.1f; 
                }          
                cuanto_x=0.0f; 
                au_y-=distancia_entre_lineas; 
            }
            
            //lineas verticales           
            int num_lineas_ver = 2000/((int)distancia_entre_lineas*10);            
            gl.glColor3f(0,255,255); 
            au_y=149.8f;
            cuanto_x=0.0f; 
            for (int ver = 0; ver <= num_lineas_ver; ver++) {  
                for (int i = 0; i < 1500; i++) { 
                    gl.glVertex2f(cuanto_x, au_y); 
                    au_y -= 0.1f;
                }
                cuanto_x+=distancia_entre_lineas;
                au_y=149.8f; 
            }
            
            gl.glEnd();            
            gl.glFlush();
        }

        public void init(GLAutoDrawable arg0) {
            glu = new GLU();
            gl = arg0.getGL();
            gl.glClearColor(0, 0, 0, 0);
            gl.glMatrixMode(gl.GL_PROJECTION);
            glu.gluOrtho2D(0, 200, 0, 150);
        }

        public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {

        }

        public void displayChanged(GLAutoDrawable drawable, boolean modeChanged, boolean deviceChanged) {

        }

    }

}
